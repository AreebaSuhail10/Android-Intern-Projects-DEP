// src/main/java/com/example/recipeapp/HomeActivity.kt
package com.example.recipeapp

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.SearchView
import androidx.appcompat.app.AppCompatActivity

class Home : AppCompatActivity() {

    private lateinit var recipeListView: ListView
    private lateinit var searchView: SearchView
    private val recipes = mutableListOf("Recipe 1", "Recipe 2", "Recipe 3") // Placeholder

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        recipeListView = findViewById(R.id.recipe_list)
        searchView = findViewById(R.id.search_box)

        val adapter = ArrayAdapter(this, R.layout.recipe_item, R.id.recipe_title, recipes)
        recipeListView.adapter = adapter

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                // Handle search query submission if needed
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                adapter.filter.filter(newText)
                return false
            }
        })
    }
}
