package com.example.recipeapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var  usernameInput : EditText
    lateinit var  passwordInput : EditText
    lateinit var  next : Button;
    private val validUsername = "user"
    private val validPassword = "password"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        usernameInput = findViewById(R.id.username)
        passwordInput = findViewById(R.id.password)
        next = findViewById(R.id.next)

        next.setOnClickListener{
            val username = usernameInput.text.toString()
            val password = passwordInput.text.toString()

            // Check if username and password are valid
            if (username == validUsername && password == validPassword) {
                // If valid, proceed to the next activity
                Log.i("Test Credentials", "Username: $username and Password: $password")
                val intent = Intent(this, Home::class.java)
                startActivity(intent)
            } else {
                // If invalid, show a toast indicating incorrect credentials
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
            }
        }
    }
}