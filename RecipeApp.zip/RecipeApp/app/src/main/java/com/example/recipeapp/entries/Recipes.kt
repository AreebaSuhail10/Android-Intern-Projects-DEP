package com.example.recipeapp.entries

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recipe_table")
data class Recipe(
 @PrimaryKey(autoGenerate = true) val id: Int = 0,
 val title: String,
 val description: String,
 val imageUrl: String
)
