package com.example.recipeapp.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.recipeapp.database.RecipeDatabase

@Dao
interface RecipeDao {
    @Insert
    suspend fun insert(recipe: RecipeDatabase)

    @Query("SELECT * FROM recipe_table WHERE id = :id")
    suspend fun getRecipeById(id: Int): RecipeDatabase?

    @Query("SELECT * FROM recipe_table")
    suspend fun getAllRecipes(): List<RecipeDatabase>
}
