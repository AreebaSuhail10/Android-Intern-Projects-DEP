package com.example.expensetracker;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class view_Summary extends AppCompatActivity {
    addDatabaseHelper db;
    ListView listView;
    ArrayList<String> listItem;
    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_summary);

        db = new addDatabaseHelper(this);
        listView = findViewById(R.id.listView);
        listItem = new ArrayList<>();
        viewData();
    }

    private void viewData() {
        Cursor cursor = db.getAllExpenses();
        if(cursor.getCount() == 0) {
            listItem.add("No expenses found");
        } else {
            while(cursor.moveToNext()) {
                listItem.add(cursor.getString(1) + " - " + cursor.getString(2) + " - " + cursor.getString(3));
            }
        }
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listItem);
        listView.setAdapter(adapter);
    }
}