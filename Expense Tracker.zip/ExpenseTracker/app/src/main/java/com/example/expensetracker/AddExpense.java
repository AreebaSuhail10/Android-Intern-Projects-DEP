package com.example.expensetracker;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddExpense extends AppCompatActivity {
    EditText editTextDescription, editTextAmount, editTextCategory;
    addDatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        editTextDescription = findViewById(R.id.editTextDescription);
        editTextAmount = findViewById(R.id.editTextAmount);
        editTextCategory = findViewById(R.id.editTextCategory);
        db = new addDatabaseHelper(this);
    }

    public void saveExpense(View view) {
        String description = editTextDescription.getText().toString();
        String amount = editTextAmount.getText().toString();
        String category = editTextCategory.getText().toString();

        if(description.isEmpty() || amount.isEmpty() || category.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
        } else {
            boolean isInserted = db.insertExpense(description, amount, category);
            if(isInserted) {
                Toast.makeText(this, "Expense Added", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Error adding expense", Toast.LENGTH_SHORT).show();
            }
        }
    }
}