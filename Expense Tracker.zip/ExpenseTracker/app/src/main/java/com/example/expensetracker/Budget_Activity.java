package com.example.expensetracker;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class BudgetActivity extends AppCompatActivity {
    EditText editTextBudgetLimit;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_budget2);

        editTextBudgetLimit = findViewById(R.id.editTextBudgetLimit);
        db = new DatabaseHelper(this);
    }

    public void saveBudget(View view) {
        String budgetLimit = editTextBudgetLimit.getText().toString();

        if(budgetLimit.isEmpty()) {
            Toast.makeText(this, "Please enter a budget limit", Toast.LENGTH_SHORT).show();
        } else {
            // Save the budget limit (this example assumes you save it in SharedPreferences)
            getSharedPreferences("ExpenseTracker", MODE_PRIVATE)
                    .edit()
                    .putString("BUDGET_LIMIT", budgetLimit)
                    .apply();
            Toast.makeText(this, "Budget Limit Set", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}