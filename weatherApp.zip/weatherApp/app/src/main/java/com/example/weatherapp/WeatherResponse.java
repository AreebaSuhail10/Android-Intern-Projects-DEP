package com.example.weatherapp;

import java.util.List;

public class WeatherResponse {
    public List<Weather> weather;
    public Main main;

    public class Weather {
        public String description;
    }

    public class Main {
        public float temp;
    }
}
