package com.example.weatherapp;

public class Forecast {
    public String date;
    public String temp;
}
