package com.example.weatherapp;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.weatherapp.ForecastAdapter;
import com.example.weatherapp.R;
import com.example.weatherapp.WeatherResponse;
import com.google.gson.Gson;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private TextView tvCurrentWeather, tvTemperature;
    private RecyclerView rvForecast;
    private ForecastAdapter forecastAdapter;
    private RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        tvCurrentWeather = findViewById(R.id.to_view_CurrentWeather);
        tvTemperature = findViewById(R.id.to_view_Temperature);
        rvForecast = findViewById(R.id.recycle_view_Forecast);

        // Check if UI components are properly initialized
        if (tvCurrentWeather == null || tvTemperature == null || rvForecast == null) {
            Log.e(TAG, "UI elements not properly initialized");
            return;
        }

        // Set up RecyclerView for forecast data
        rvForecast.setLayoutManager(new LinearLayoutManager(this));
        forecastAdapter = new ForecastAdapter();
        rvForecast.setAdapter(forecastAdapter);

        // Initialize the request queue
        requestQueue = Volley.newRequestQueue(this);

        // Fetch weather data for a default city (e.g., Lahore)
        fetchWeatherData("Lahore");
    }

    private void fetchWeatherData(String city) {
        // Replace with your actual API key
        String apiKey = "your_actual_api_key_here";
        String url = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apiKey;

        // Create a string request to fetch weather data
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Parse and handle the response
                        try {
                            Gson gson = new Gson();
                            WeatherResponse weatherResponse = gson.fromJson(response, WeatherResponse.class);
                            if (weatherResponse != null && weatherResponse.weather != null && !weatherResponse.weather.isEmpty()) {
                                tvCurrentWeather.setText(weatherResponse.weather.get(0).description);
                                tvTemperature.setText(String.valueOf(weatherResponse.main.temp) + "°C");
                            } else {
                                Log.e(TAG, "WeatherResponse or its data is null");
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error parsing response: " + e.getMessage());
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // Handle error
                tvCurrentWeather.setText("Error fetching data");
                Log.e(TAG, "Error fetching data: " + error.getMessage());
            }
        });

        // Add the request to the request queue
        requestQueue.add(stringRequest);
    }
}